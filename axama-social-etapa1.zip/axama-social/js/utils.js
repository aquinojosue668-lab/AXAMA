/**
 * AXAMA Social — Utilidades generales
 * --------------------------------------------------------------
 * Funciones puras y helpers de DOM reutilizables en toda la app.
 * --------------------------------------------------------------
 */

/**
 * Selecciona un único elemento del DOM.
 * @param {string} selector
 * @param {ParentNode} [scope]
 * @returns {Element|null}
 */
export function qs(selector, scope = document) {
  return scope.querySelector(selector);
}

/**
 * Selecciona varios elementos del DOM como array.
 * @param {string} selector
 * @param {ParentNode} [scope]
 * @returns {Element[]}
 */
export function qsa(selector, scope = document) {
  return Array.from(scope.querySelectorAll(selector));
}

/**
 * Crea un elemento DOM con atributos y contenido, de forma segura
 * (usa textContent, nunca innerHTML, para evitar inyección de HTML).
 * @param {string} tag
 * @param {Object} [attrs]
 * @param {string} [text]
 * @returns {HTMLElement}
 */
export function createEl(tag, attrs = {}, text = "") {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (key === "className") {
      el.className = value;
    } else if (key.startsWith("data-")) {
      el.setAttribute(key, value);
    } else {
      el[key] = value;
    }
  }
  if (text) el.textContent = text;
  return el;
}

/**
 * Muestra un toast (notificación flotante breve y no intrusiva).
 * @param {string} message
 * @param {"info"|"error"} [type]
 */
export function showToast(message, type = "info") {
  let toast = qs("#axama-toast");
  if (!toast) {
    toast = createEl("div", { id: "axama-toast", className: "toast", role: "status", "aria-live": "polite" });
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.style.backgroundColor = type === "error" ? "var(--color-danger)" : "var(--color-text)";
  toast.classList.add("is-visible");

  clearTimeout(toast._hideTimeout);
  toast._hideTimeout = setTimeout(() => {
    toast.classList.remove("is-visible");
  }, 3200);
}

/**
 * Formatea una fecha ISO a un formato legible en español.
 * Ej: "17 jun 2026, 14:30"
 * @param {string} isoDate
 * @returns {string}
 */
export function formatDate(isoDate) {
  const date = new Date(isoDate);
  if (Number.isNaN(date.getTime())) return "";
  return new Intl.DateTimeFormat("es-MX", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

/**
 * Formatea una fecha como tiempo relativo ("hace 5 min", "hace 2 h").
 * Se mantiene sobrio, sin urgencia artificial.
 * @param {string} isoDate
 * @returns {string}
 */
export function formatRelativeTime(isoDate) {
  const date = new Date(isoDate);
  const now = new Date();
  const diffSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  if (diffSeconds < 60) return "ahora";
  if (diffSeconds < 3600) return `hace ${Math.floor(diffSeconds / 60)} min`;
  if (diffSeconds < 86400) return `hace ${Math.floor(diffSeconds / 3600)} h`;
  if (diffSeconds < 604800) return `hace ${Math.floor(diffSeconds / 86400)} d`;
  return formatDate(isoDate);
}

/**
 * Valida formato básico de correo electrónico.
 * @param {string} email
 * @returns {boolean}
 */
export function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

/**
 * Valida que el nombre de usuario cumpla el formato permitido:
 * 3-20 caracteres, letras, números y guion bajo.
 * @param {string} username
 * @returns {boolean}
 */
export function isValidUsername(username) {
  return /^[a-zA-Z0-9_]{3,20}$/.test(username.trim());
}

/**
 * Evalúa la fortaleza de una contraseña de forma simple (0 a 4).
 * No es punitivo: solo informa, no bloquea decisiones del usuario.
 * @param {string} password
 * @returns {number}
 */
export function getPasswordStrength(password) {
  let score = 0;
  if (password.length >= 8) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;
  return score;
}

/**
 * Obtiene parámetros de la query string actual.
 * @returns {URLSearchParams}
 */
export function getQueryParams() {
  return new URLSearchParams(window.location.search);
}

/**
 * Redirige a otra página del sitio.
 * @param {string} path
 */
export function redirectTo(path) {
  window.location.href = path;
}

/**
 * Debounce simple para inputs de búsqueda u otros eventos frecuentes.
 * @param {Function} fn
 * @param {number} delay
 * @returns {Function}
 */
export function debounce(fn, delay = 350) {
  let timeoutId;
  return (...args) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => fn(...args), delay);
  };
}

/**
 * Trunca un texto a una longitud máxima, agregando puntos suspensivos.
 * @param {string} text
 * @param {number} maxLength
 * @returns {string}
 */
export function truncateText(text, maxLength = 280) {
  if (!text || text.length <= maxLength) return text;
  return `${text.slice(0, maxLength).trimEnd()}…`;
}
