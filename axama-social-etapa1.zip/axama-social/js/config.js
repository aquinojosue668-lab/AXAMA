/**
 * AXAMA Social — Configuración
 * --------------------------------------------------------------
 * Pega aquí los datos de tu proyecto de Supabase.
 * Los encuentras en: Supabase Dashboard > Project Settings > API
 *
 * SUPABASE_URL   -> "Project URL"
 * SUPABASE_ANON_KEY -> "anon public" key
 *
 * IMPORTANTE: la "anon key" es segura para usarse en el frontend
 * (está diseñada para ello). NUNCA pongas aquí la "service_role key".
 * La seguridad real se aplica con las políticas RLS en la base de datos
 * (ver /sql/schema.sql), no ocultando esta clave.
 * --------------------------------------------------------------
 */

export const SUPABASE_URL = "https://TU-PROYECTO.supabase.co";
export const SUPABASE_ANON_KEY = "TU-ANON-KEY-AQUI";

/**
 * Configuración general de la app.
 */
export const APP_CONFIG = {
  appName: "AXAMA Social",
  postsPerPage: 10,
  maxImagesPerPost: 4,
  maxImageSizeMB: 5,
  bucketAvatars: "avatars",
  bucketPosts: "posts",
};
