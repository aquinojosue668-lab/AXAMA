/**
 * AXAMA Social — Cliente de Supabase
 * --------------------------------------------------------------
 * Este módulo expone una única instancia del cliente de Supabase
 * para que toda la app la reutilice (patrón singleton).
 *
 * NOTA TÉCNICA: el SDK de Supabase se carga en el HTML mediante
 * la build UMD clásica:
 *
 *   <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js"></script>
 *
 * y NO mediante "+esm" de jsDelivr. Esto es deliberado: la variante
 * ESM de Supabase-js v2 vía jsDelivr tiene un bug conocido que rompe
 * el cliente en el navegador (módulos internos que exportan
 * `default null`, provocando errores como
 * "Cannot read properties of null (reading 'AuthClient')").
 * La build UMD expone un objeto global `supabase` del cual extraemos
 * `createClient`, y es la forma estable recomendada para uso sin
 * bundler. Por eso el <script> del SDK se carga ANTES de este
 * archivo y SIN type="module" en index.html y en las páginas.
 * --------------------------------------------------------------
 */

import { SUPABASE_URL, SUPABASE_ANON_KEY } from "./config.js";

if (typeof window.supabase === "undefined") {
  throw new Error(
    "El SDK de Supabase no se cargó. Verifica que el <script> del CDN " +
    "esté incluido en el HTML ANTES de este módulo."
  );
}

const { createClient } = window.supabase;

/**
 * Instancia única del cliente de Supabase, compartida por toda la app.
 * persistSession: true  -> mantiene la sesión activa entre recargas.
 * autoRefreshToken: true -> renueva el token automáticamente.
 */
export const supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});
