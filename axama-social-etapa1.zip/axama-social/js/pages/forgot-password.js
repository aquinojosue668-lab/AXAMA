/**
 * AXAMA Social — Página: Recuperar contraseña
 * --------------------------------------------------------------
 * Etapa 1: validación de formulario en el cliente únicamente.
 * La conexión real con Supabase Auth (resetPasswordForEmail) se
 * implementa en la Etapa 3 (Autenticación).
 * --------------------------------------------------------------
 */

import { isValidEmail, qs } from "../utils.js";

function handleSubmit(event) {
  event.preventDefault();

  const emailInput = qs("#email");

  if (!isValidEmail(emailInput.value)) {
    emailInput.setAttribute("aria-invalid", "true");
    return;
  }

  // --------------------------------------------------------------
  // PUNTO DE INTEGRACIÓN — Etapa 3 (Autenticación)
  // Aquí se llamará a:
  //   await supabaseClient.auth.resetPasswordForEmail(emailInput.value.trim(), {
  //     redirectTo: `${window.location.origin}/pages/reset-password.html`,
  //   });
  // --------------------------------------------------------------
  qs("#request-view").hidden = true;
  qs("#sent-view").hidden = false;
}

function init() {
  const form = qs("#forgot-form");
  if (form) form.addEventListener("submit", handleSubmit);
}

document.addEventListener("DOMContentLoaded", init);
