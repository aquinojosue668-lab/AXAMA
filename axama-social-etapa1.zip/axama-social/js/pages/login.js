/**
 * AXAMA Social — Página: Login
 * --------------------------------------------------------------
 * Etapa 1: validación de formulario en el cliente únicamente.
 * La conexión real con Supabase Auth (signInWithPassword) se
 * implementa en la Etapa 3 (Autenticación). Este archivo queda
 * preparado con el punto de integración marcado explícitamente.
 * --------------------------------------------------------------
 */

import { isValidEmail, qs } from "../utils.js";

function showFieldError(input, errorEl, message) {
  input.setAttribute("aria-invalid", "true");
  errorEl.textContent = message;
  errorEl.hidden = false;
}

function clearFieldError(input, errorEl) {
  input.removeAttribute("aria-invalid");
  errorEl.hidden = true;
}

function handleSubmit(event) {
  event.preventDefault();

  const emailInput = qs("#email");
  const passwordInput = qs("#password");
  const emailError = qs("#email-error");
  const passwordError = qs("#password-error");

  clearFieldError(emailInput, emailError);
  clearFieldError(passwordInput, passwordError);

  let hasError = false;

  if (!isValidEmail(emailInput.value)) {
    showFieldError(emailInput, emailError, "Ingresa un correo válido.");
    hasError = true;
  }

  if (passwordInput.value.length === 0) {
    showFieldError(passwordInput, passwordError, "Ingresa tu contraseña.");
    hasError = true;
  }

  if (hasError) return;

  // --------------------------------------------------------------
  // PUNTO DE INTEGRACIÓN — Etapa 3 (Autenticación)
  // Aquí se llamará a:
  //   const { error } = await supabaseClient.auth.signInWithPassword({
  //     email: emailInput.value.trim(),
  //     password: passwordInput.value,
  //   });
  // y se redirigirá a /index.html si no hay error.
  // --------------------------------------------------------------
  console.info("[AXAMA] Formulario válido. Conexión con Supabase Auth pendiente de Etapa 3.");
}

function init() {
  const form = qs("#login-form");
  if (form) form.addEventListener("submit", handleSubmit);
}

document.addEventListener("DOMContentLoaded", init);
