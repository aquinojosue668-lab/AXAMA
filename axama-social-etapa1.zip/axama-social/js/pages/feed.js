/**
 * AXAMA Social — Página: Feed (inicio)
 * --------------------------------------------------------------
 * Etapa 1: solo inicializa la estructura visual (header, footer,
 * tema). La carga real de publicaciones, paginación y el formulario
 * para publicar se conectan en la Etapa 5 (Publicaciones), una vez
 * exista la sesión autenticada (Etapa 3).
 * --------------------------------------------------------------
 */

import { renderHeader } from "../../components/header.js";
import { renderFooter } from "../../components/footer.js";
import { initThemeToggle } from "../theme.js";

function init() {
  renderHeader("#app-header");
  renderFooter("#app-footer");
  initThemeToggle();
}

document.addEventListener("DOMContentLoaded", init);
