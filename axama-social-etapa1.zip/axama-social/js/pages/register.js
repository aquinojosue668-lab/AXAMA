/**
 * AXAMA Social — Página: Registro
 * --------------------------------------------------------------
 * Etapa 1: validación de formulario en el cliente únicamente.
 * La conexión real con Supabase Auth (signUp) se implementa en
 * la Etapa 3 (Autenticación).
 * --------------------------------------------------------------
 */

import { isValidEmail, isValidUsername, getPasswordStrength, qs, qsa } from "../utils.js";

function showFieldError(input, errorEl, message) {
  input.setAttribute("aria-invalid", "true");
  errorEl.textContent = message;
  errorEl.hidden = false;
}

function clearFieldError(input, errorEl) {
  input.removeAttribute("aria-invalid");
  errorEl.hidden = true;
}

function updatePasswordStrengthBars(password) {
  const bars = qsa("#password-strength .password-strength__bar");
  const score = getPasswordStrength(password);
  bars.forEach((bar, index) => {
    bar.classList.toggle("is-active", index < score);
  });
}

function handleSubmit(event) {
  event.preventDefault();

  const usernameInput = qs("#username");
  const emailInput = qs("#email");
  const passwordInput = qs("#password");
  const usernameError = qs("#username-error");
  const emailError = qs("#email-error");
  const passwordError = qs("#password-error");

  clearFieldError(usernameInput, usernameError);
  clearFieldError(emailInput, emailError);
  clearFieldError(passwordInput, passwordError);

  let hasError = false;

  if (!isValidUsername(usernameInput.value)) {
    showFieldError(usernameInput, usernameError, "Usa 3 a 20 caracteres: letras, números o guion bajo.");
    hasError = true;
  }

  if (!isValidEmail(emailInput.value)) {
    showFieldError(emailInput, emailError, "Ingresa un correo válido.");
    hasError = true;
  }

  if (passwordInput.value.length < 8) {
    showFieldError(passwordInput, passwordError, "La contraseña debe tener al menos 8 caracteres.");
    hasError = true;
  }

  if (hasError) return;

  // --------------------------------------------------------------
  // PUNTO DE INTEGRACIÓN — Etapa 3 (Autenticación)
  // Aquí se llamará a:
  //   const { error } = await supabaseClient.auth.signUp({
  //     email: emailInput.value.trim(),
  //     password: passwordInput.value,
  //     options: {
  //       data: {
  //         username: usernameInput.value.trim(),
  //         full_name: qs("#full-name").value.trim(),
  //       },
  //     },
  //   });
  // y se mostrará la vista de "verifica tu correo".
  // --------------------------------------------------------------
  console.info("[AXAMA] Formulario válido. Conexión con Supabase Auth pendiente de Etapa 3.");
}

function init() {
  const form = qs("#register-form");
  const passwordInput = qs("#password");

  if (form) form.addEventListener("submit", handleSubmit);
  if (passwordInput) {
    passwordInput.addEventListener("input", (e) => updatePasswordStrengthBars(e.target.value));
  }
}

document.addEventListener("DOMContentLoaded", init);
