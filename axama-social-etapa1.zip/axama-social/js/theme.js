/**
 * AXAMA Social — Tema (modo claro / oscuro)
 * --------------------------------------------------------------
 * Gestiona la preferencia de tema del usuario, persistida en
 * localStorage. Si el usuario no ha elegido manualmente, se respeta
 * la preferencia del sistema operativo (prefers-color-scheme),
 * gestionada vía CSS en variables.css.
 * --------------------------------------------------------------
 */

const THEME_STORAGE_KEY = "axama-theme";

/**
 * Aplica el tema guardado (si existe) al cargar la página.
 * Debe llamarse lo antes posible para evitar parpadeos visuales.
 */
export function applyStoredTheme() {
  const stored = localStorage.getItem(THEME_STORAGE_KEY);
  if (stored === "dark" || stored === "light") {
    document.documentElement.setAttribute("data-theme", stored);
  }
}

/**
 * Devuelve el tema actualmente activo ("dark" o "light"),
 * considerando preferencia guardada o del sistema.
 * @returns {"dark"|"light"}
 */
export function getCurrentTheme() {
  const stored = localStorage.getItem(THEME_STORAGE_KEY);
  if (stored === "dark" || stored === "light") return stored;
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

/**
 * Alterna entre modo claro y oscuro, y guarda la preferencia.
 */
export function toggleTheme() {
  const next = getCurrentTheme() === "dark" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", next);
  localStorage.setItem(THEME_STORAGE_KEY, next);
  updateThemeToggleIcon(next);
}

/**
 * Actualiza el ícono del botón de cambio de tema según el tema activo.
 * @param {"dark"|"light"} theme
 */
function updateThemeToggleIcon(theme) {
  const button = document.querySelector("[data-theme-toggle]");
  if (!button) return;
  button.setAttribute(
    "aria-label",
    theme === "dark" ? "Cambiar a modo claro" : "Cambiar a modo oscuro"
  );
}

/**
 * Inicializa el botón de cambio de tema, si existe en la página actual.
 */
export function initThemeToggle() {
  applyStoredTheme();
  const button = document.querySelector("[data-theme-toggle]");
  if (!button) return;
  updateThemeToggleIcon(getCurrentTheme());
  button.addEventListener("click", toggleTheme);
}
