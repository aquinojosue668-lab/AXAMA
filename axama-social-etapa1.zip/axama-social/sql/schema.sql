-- ============================================================================
-- AXAMA Social — Esquema de base de datos para Supabase (PostgreSQL)
-- ============================================================================
-- Cómo usar este archivo:
-- 1. Entra a tu proyecto en https://app.supabase.com
-- 2. Ve a "SQL Editor" > "New query"
-- 3. Pega TODO este archivo y ejecútalo (Run)
-- 4. Ve a "Storage" y crea los buckets indicados al final de este archivo
--    (esto se hace desde la interfaz, no por SQL)
--
-- Este esquema cubre TODO el proyecto (todas las etapas). Se ejecuta una
-- sola vez completo; cada etapa de desarrollo simplemente usará las tablas
-- que le correspondan.
-- ============================================================================


-- ----------------------------------------------------------------------------
-- EXTENSIONES NECESARIAS
-- ----------------------------------------------------------------------------
create extension if not exists "uuid-ossp";


-- ============================================================================
-- 1. PERFILES (profiles)
-- ----------------------------------------------------------------------------
-- Se crea automáticamente cuando un usuario se registra en Supabase Auth,
-- mediante un trigger sobre auth.users (ver sección de triggers).
-- ============================================================================

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  full_name text not null default '',
  avatar_url text,
  bio text default '',
  city text default '',
  website text default '',
  role text not null default 'user', -- 'user' | 'admin'
  is_suspended boolean not null default false,
  created_at timestamptz not null default now(),

  constraint username_format check (username ~ '^[a-zA-Z0-9_]{3,20}$'),
  constraint role_valid check (role in ('user', 'admin'))
);

create index idx_profiles_username on public.profiles (username);
create index idx_profiles_role on public.profiles (role);

comment on table public.profiles is 'Datos públicos de perfil de cada usuario registrado.';


-- ============================================================================
-- 2. PUBLICACIONES (posts)
-- ============================================================================

create table public.posts (
  id uuid primary key default uuid_generate_v4(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  content text not null default '',
  created_at timestamptz not null default now(),

  constraint content_or_images check (char_length(content) > 0 or true)
  -- (la validación de "al menos contenido o imagen" se refuerza en la app;
  -- a nivel BD permitimos texto vacío si hay imágenes asociadas)
);

create index idx_posts_author_id on public.posts (author_id);
create index idx_posts_created_at on public.posts (created_at desc);

comment on table public.posts is 'Publicaciones de texto. Las imágenes asociadas viven en post_images.';


-- ============================================================================
-- 3. IMÁGENES DE PUBLICACIONES (post_images)
-- ----------------------------------------------------------------------------
-- Una publicación puede tener varias imágenes (relación 1 a N).
-- ============================================================================

create table public.post_images (
  id uuid primary key default uuid_generate_v4(),
  post_id uuid not null references public.posts(id) on delete cascade,
  storage_path text not null,
  position smallint not null default 0,
  created_at timestamptz not null default now()
);

create index idx_post_images_post_id on public.post_images (post_id);

comment on table public.post_images is 'Rutas de imágenes en Supabase Storage asociadas a una publicación.';


-- ============================================================================
-- 4. COMENTARIOS (comments)
-- ============================================================================

create table public.comments (
  id uuid primary key default uuid_generate_v4(),
  post_id uuid not null references public.posts(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  content text not null,
  created_at timestamptz not null default now(),

  constraint comment_not_empty check (char_length(trim(content)) > 0)
);

create index idx_comments_post_id on public.comments (post_id);
create index idx_comments_author_id on public.comments (author_id);

comment on table public.comments is 'Comentarios sobre publicaciones.';


-- ============================================================================
-- 5. LIKES (likes)
-- ----------------------------------------------------------------------------
-- Única reacción soportada: "me gusta". Un usuario solo puede dar like
-- una vez por publicación (clave única compuesta).
-- ============================================================================

create table public.likes (
  id uuid primary key default uuid_generate_v4(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),

  constraint unique_like_per_user_post unique (post_id, user_id)
);

create index idx_likes_post_id on public.likes (post_id);
create index idx_likes_user_id on public.likes (user_id);

comment on table public.likes is 'Reacciones de "me gusta" sobre publicaciones.';


-- ============================================================================
-- 6. SEGUIDORES (follows)
-- ----------------------------------------------------------------------------
-- Relación muchos-a-muchos entre usuarios: follower_id sigue a following_id.
-- ============================================================================

create table public.follows (
  id uuid primary key default uuid_generate_v4(),
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),

  constraint unique_follow_pair unique (follower_id, following_id),
  constraint no_self_follow check (follower_id <> following_id)
);

create index idx_follows_follower_id on public.follows (follower_id);
create index idx_follows_following_id on public.follows (following_id);

comment on table public.follows is 'Relaciones de seguimiento entre usuarios.';


-- ============================================================================
-- 7. CONVERSACIONES Y MENSAJES PRIVADOS (conversations, messages)
-- ----------------------------------------------------------------------------
-- Conversaciones uno a uno. Se normaliza el par de usuarios para evitar
-- conversaciones duplicadas (user_a_id siempre es el menor de los dos UUIDs
-- en orden de texto, gestionado por la app o un trigger).
-- ============================================================================

create table public.conversations (
  id uuid primary key default uuid_generate_v4(),
  user_a_id uuid not null references public.profiles(id) on delete cascade,
  user_b_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),

  constraint unique_conversation_pair unique (user_a_id, user_b_id),
  constraint no_self_conversation check (user_a_id <> user_b_id)
);

create index idx_conversations_user_a on public.conversations (user_a_id);
create index idx_conversations_user_b on public.conversations (user_b_id);

create table public.messages (
  id uuid primary key default uuid_generate_v4(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  content text not null,
  created_at timestamptz not null default now(),

  constraint message_not_empty check (char_length(trim(content)) > 0)
);

create index idx_messages_conversation_id on public.messages (conversation_id, created_at);
create index idx_messages_sender_id on public.messages (sender_id);

comment on table public.conversations is 'Conversaciones privadas uno a uno entre dos usuarios.';
comment on table public.messages is 'Mensajes individuales dentro de una conversación. Sin confirmaciones de lectura ni indicador de escritura, por diseño.';


-- ============================================================================
-- 8. NOTIFICACIONES (notifications)
-- ----------------------------------------------------------------------------
-- Solo 3 tipos permitidos: nuevo seguidor, nuevo comentario, nuevo like.
-- ============================================================================

create table public.notifications (
  id uuid primary key default uuid_generate_v4(),
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid not null references public.profiles(id) on delete cascade,
  type text not null,
  post_id uuid references public.posts(id) on delete cascade,
  is_read boolean not null default false,
  created_at timestamptz not null default now(),

  constraint type_valid check (type in ('new_follower', 'new_comment', 'new_like'))
);

create index idx_notifications_recipient_id on public.notifications (recipient_id, created_at desc);
create index idx_notifications_is_read on public.notifications (recipient_id, is_read);

comment on table public.notifications is 'Notificaciones limitadas a 3 tipos, sin generar ansiedad ni ruido excesivo.';


-- ============================================================================
-- TRIGGERS Y FUNCIONES AUXILIARES
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 9.1 Crear perfil automáticamente al registrarse un usuario en auth.users
-- ----------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, username, full_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', 'user_' || substr(new.id::text, 1, 8)),
    coalesce(new.raw_user_meta_data->>'full_name', '')
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();


-- ----------------------------------------------------------------------------
-- 9.2 Notificar nuevo seguidor
-- ----------------------------------------------------------------------------
create or replace function public.handle_new_follow()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.notifications (recipient_id, actor_id, type)
  values (new.following_id, new.follower_id, 'new_follower');
  return new;
end;
$$;

create trigger on_follow_created
  after insert on public.follows
  for each row execute function public.handle_new_follow();


-- ----------------------------------------------------------------------------
-- 9.3 Notificar nuevo comentario (al autor de la publicación, si no es él mismo)
-- ----------------------------------------------------------------------------
create or replace function public.handle_new_comment()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  post_author_id uuid;
begin
  select author_id into post_author_id from public.posts where id = new.post_id;

  if post_author_id is not null and post_author_id <> new.author_id then
    insert into public.notifications (recipient_id, actor_id, type, post_id)
    values (post_author_id, new.author_id, 'new_comment', new.post_id);
  end if;

  return new;
end;
$$;

create trigger on_comment_created
  after insert on public.comments
  for each row execute function public.handle_new_comment();


-- ----------------------------------------------------------------------------
-- 9.4 Notificar nuevo like (al autor de la publicación, si no es él mismo)
-- ----------------------------------------------------------------------------
create or replace function public.handle_new_like()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  post_author_id uuid;
begin
  select author_id into post_author_id from public.posts where id = new.post_id;

  if post_author_id is not null and post_author_id <> new.user_id then
    insert into public.notifications (recipient_id, actor_id, type, post_id)
    values (post_author_id, new.user_id, 'new_like', new.post_id);
  end if;

  return new;
end;
$$;

create trigger on_like_created
  after insert on public.likes
  for each row execute function public.handle_new_like();


-- ============================================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================================
-- Se activa RLS en TODAS las tablas. Por defecto, sin políticas, esto
-- bloquea todo acceso; las políticas siguientes habilitan exactamente
-- lo necesario.
-- ============================================================================

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.post_images enable row level security;
alter table public.comments enable row level security;
alter table public.likes enable row level security;
alter table public.follows enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;


-- ----------------------------------------------------------------------------
-- 10.1 Políticas: profiles
-- ----------------------------------------------------------------------------

-- Cualquiera autenticado puede ver perfiles (necesario para perfiles públicos,
-- búsqueda de usuarios y panel de administración).
create policy "profiles_select_all"
  on public.profiles for select
  to authenticated
  using (true);

-- Un usuario solo puede actualizar su propio perfil.
-- (la suspensión de cuentas y cambio de rol se hace vía panel admin con
-- función dedicada, ver 10.9, para que un usuario no pueda auto-promoverse).
create policy "profiles_update_own"
  on public.profiles for update
  to authenticated
  using (auth.uid() = id)
  with check (auth.uid() = id and role = (select role from public.profiles where id = auth.uid()));

-- La inserción de perfiles ocurre solo vía el trigger handle_new_user
-- (security definer), por lo que no se habilita insert directo desde el cliente.


-- ----------------------------------------------------------------------------
-- 10.2 Políticas: posts
-- ----------------------------------------------------------------------------

-- Cualquiera autenticado puede ver publicaciones de cuentas no suspendidas.
create policy "posts_select_all"
  on public.posts for select
  to authenticated
  using (
    exists (
      select 1 from public.profiles
      where profiles.id = posts.author_id
      and profiles.is_suspended = false
    )
  );

-- Solo el propio usuario puede crear publicaciones a su nombre.
create policy "posts_insert_own"
  on public.posts for insert
  to authenticated
  with check (auth.uid() = author_id);

-- Solo el autor (o un admin) puede eliminar su publicación.
create policy "posts_delete_own_or_admin"
  on public.posts for delete
  to authenticated
  using (
    auth.uid() = author_id
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );


-- ----------------------------------------------------------------------------
-- 10.3 Políticas: post_images
-- ----------------------------------------------------------------------------

create policy "post_images_select_all"
  on public.post_images for select
  to authenticated
  using (true);

-- Solo se puede agregar una imagen a una publicación propia.
create policy "post_images_insert_own_post"
  on public.post_images for insert
  to authenticated
  with check (
    exists (
      select 1 from public.posts
      where posts.id = post_images.post_id
      and posts.author_id = auth.uid()
    )
  );

create policy "post_images_delete_own_post_or_admin"
  on public.post_images for delete
  to authenticated
  using (
    exists (
      select 1 from public.posts
      where posts.id = post_images.post_id
      and posts.author_id = auth.uid()
    )
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );


-- ----------------------------------------------------------------------------
-- 10.4 Políticas: comments
-- ----------------------------------------------------------------------------

create policy "comments_select_all"
  on public.comments for select
  to authenticated
  using (true);

create policy "comments_insert_own"
  on public.comments for insert
  to authenticated
  with check (auth.uid() = author_id);

-- Solo el autor del comentario (o un admin) puede eliminarlo.
create policy "comments_delete_own_or_admin"
  on public.comments for delete
  to authenticated
  using (
    auth.uid() = author_id
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );


-- ----------------------------------------------------------------------------
-- 10.5 Políticas: likes
-- ----------------------------------------------------------------------------

create policy "likes_select_all"
  on public.likes for select
  to authenticated
  using (true);

create policy "likes_insert_own"
  on public.likes for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Un usuario solo puede quitar su propio like.
create policy "likes_delete_own"
  on public.likes for delete
  to authenticated
  using (auth.uid() = user_id);


-- ----------------------------------------------------------------------------
-- 10.6 Políticas: follows
-- ----------------------------------------------------------------------------

create policy "follows_select_all"
  on public.follows for select
  to authenticated
  using (true);

create policy "follows_insert_own"
  on public.follows for insert
  to authenticated
  with check (auth.uid() = follower_id);

create policy "follows_delete_own"
  on public.follows for delete
  to authenticated
  using (auth.uid() = follower_id);


-- ----------------------------------------------------------------------------
-- 10.7 Políticas: conversations y messages
-- ----------------------------------------------------------------------------
-- Solo los dos participantes de una conversación pueden verla o escribir
-- mensajes en ella. Esto es crítico para la privacidad de la mensajería.
-- ----------------------------------------------------------------------------

create policy "conversations_select_participant"
  on public.conversations for select
  to authenticated
  using (auth.uid() = user_a_id or auth.uid() = user_b_id);

create policy "conversations_insert_participant"
  on public.conversations for insert
  to authenticated
  with check (auth.uid() = user_a_id or auth.uid() = user_b_id);

create policy "messages_select_participant"
  on public.messages for select
  to authenticated
  using (
    exists (
      select 1 from public.conversations
      where conversations.id = messages.conversation_id
      and (conversations.user_a_id = auth.uid() or conversations.user_b_id = auth.uid())
    )
  );

create policy "messages_insert_participant"
  on public.messages for insert
  to authenticated
  with check (
    auth.uid() = sender_id
    and exists (
      select 1 from public.conversations
      where conversations.id = messages.conversation_id
      and (conversations.user_a_id = auth.uid() or conversations.user_b_id = auth.uid())
    )
  );


-- ----------------------------------------------------------------------------
-- 10.8 Políticas: notifications
-- ----------------------------------------------------------------------------
-- Un usuario solo puede ver y marcar como leídas sus propias notificaciones.
-- La inserción ocurre exclusivamente vía triggers (security definer).
-- ----------------------------------------------------------------------------

create policy "notifications_select_own"
  on public.notifications for select
  to authenticated
  using (auth.uid() = recipient_id);

create policy "notifications_update_own"
  on public.notifications for update
  to authenticated
  using (auth.uid() = recipient_id)
  with check (auth.uid() = recipient_id);


-- ----------------------------------------------------------------------------
-- 10.9 Función administrativa: suspender/reactivar cuentas
-- ----------------------------------------------------------------------------
-- Permite a un admin cambiar is_suspended sin exponer una policy de UPDATE
-- abierta sobre profiles (lo que podría permitir auto-promoción de rol).
-- ----------------------------------------------------------------------------

create or replace function public.admin_set_user_suspended(target_user_id uuid, suspended boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (select 1 from public.profiles where id = auth.uid() and role = 'admin') then
    raise exception 'Solo administradores pueden ejecutar esta acción.';
  end if;

  update public.profiles set is_suspended = suspended where id = target_user_id;
end;
$$;

-- ----------------------------------------------------------------------------
-- 10.10 Función administrativa: eliminar cualquier publicación
-- ----------------------------------------------------------------------------
-- Nota: la policy "posts_delete_own_or_admin" (10.2) ya permite a un admin
-- eliminar directamente vía delete. Esta función es un envoltorio explícito
-- opcional, útil si se prefiere invocar vía RPC desde el panel admin.
-- ----------------------------------------------------------------------------

create or replace function public.admin_delete_post(target_post_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (select 1 from public.profiles where id = auth.uid() and role = 'admin') then
    raise exception 'Solo administradores pueden ejecutar esta acción.';
  end if;

  delete from public.posts where id = target_post_id;
end;
$$;


-- ============================================================================
-- VISTA DE ESTADÍSTICAS BÁSICAS PARA EL PANEL DE ADMINISTRACIÓN
-- ============================================================================

create or replace view public.admin_stats as
select
  (select count(*) from public.profiles) as total_users,
  (select count(*) from public.profiles where is_suspended = true) as suspended_users,
  (select count(*) from public.posts) as total_posts,
  (select count(*) from public.comments) as total_comments,
  (select count(*) from public.likes) as total_likes;

comment on view public.admin_stats is 'Estadísticas agregadas de uso, solo para consulta del panel de administración.';


-- ============================================================================
-- ALMACENAMIENTO (Supabase Storage)
-- ============================================================================
-- Los buckets se crean desde la interfaz de Supabase (Storage > New bucket),
-- NO por SQL. Crea exactamente estos dos buckets, ambos como PÚBLICOS
-- (public bucket) para que las imágenes se puedan mostrar directamente
-- por URL sin necesidad de URLs firmadas:
--
--   1. "avatars"  -> fotos de perfil
--   2. "posts"    -> imágenes de publicaciones
--
-- Después de crear los buckets, ejecuta las políticas de abajo para
-- controlar quién puede subir/eliminar archivos (storage.objects también
-- usa RLS internamente).
-- ============================================================================

create policy "avatar_upload_own_folder"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "avatar_update_own_folder"
  on storage.objects for update
  to authenticated
  using (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "avatar_delete_own_folder"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "avatar_public_read"
  on storage.objects for select
  to public
  using (bucket_id = 'avatars');

create policy "post_images_upload_own_folder"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'posts'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "post_images_delete_own_folder"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'posts'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "post_images_public_read"
  on storage.objects for select
  to public
  using (bucket_id = 'posts');

-- ============================================================================
-- FIN DEL ESQUEMA
-- ============================================================================
