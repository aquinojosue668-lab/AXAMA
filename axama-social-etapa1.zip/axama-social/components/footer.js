/**
 * AXAMA Social — Componente: Footer
 * --------------------------------------------------------------
 * Pie de página con enlaces básicos. Sin enlaces a redes externas
 * ni elementos que fomenten salir de la app hacia mecanismos de
 * distracción — coherente con la filosofía del proyecto.
 * --------------------------------------------------------------
 */

import { qs } from "../js/utils.js";

export function renderFooter(containerSelector) {
  const container = qs(containerSelector);
  if (!container) return;

  const year = new Date().getFullYear();

  container.innerHTML = `
    <div class="app-footer__inner">
      <span>© ${year} AXAMA Social</span>
      <div class="app-footer__links">
        <a href="/pages/about.html">Acerca de</a>
        <a href="/pages/privacy.html">Privacidad</a>
      </div>
    </div>
  `;
}
