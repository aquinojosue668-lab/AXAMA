/**
 * AXAMA Social — Componente: Header
 * --------------------------------------------------------------
 * Inserta el encabezado de la aplicación (logo, búsqueda, navegación,
 * toggle de tema) dentro de cualquier elemento contenedor.
 * Se usa en todas las páginas internas (no en login/registro).
 * --------------------------------------------------------------
 */

import { createEl, qs } from "../js/utils.js";

const SUN_ICON = `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="4.5"/><path d="M12 3v2.2M12 18.8V21M4.93 4.93l1.55 1.55M17.52 17.52l1.55 1.55M3 12h2.2M18.8 12H21M4.93 19.07l1.55-1.55M17.52 6.48l1.55-1.55"/></svg>`;
const SEARCH_ICON = `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.2-3.2"/></svg>`;
const BELL_ICON = `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M6 9a6 6 0 1 1 12 0c0 4 1.5 5.5 1.5 5.5H4.5S6 13 6 9Z"/><path d="M9.5 17.5a2.5 2.5 0 0 0 5 0"/></svg>`;
const MAIL_ICON = `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>`;

/**
 * Renderiza el header dentro del contenedor indicado.
 * @param {string} containerSelector
 * @param {Object} [options]
 * @param {string} [options.activeUsername] - username del usuario logueado, para el enlace a su perfil.
 */
export function renderHeader(containerSelector, options = {}) {
  const container = qs(containerSelector);
  if (!container) return;

  container.innerHTML = `
    <div class="app-header__inner">
      <a href="/index.html" class="app-header__brand">
        <span class="app-header__brand-mark" aria-hidden="true"></span>
        <span>AXAMA</span>
      </a>

      <form class="app-header__search" role="search" data-search-form>
        <label for="header-search" class="sr-only">Buscar personas</label>
        <input
          type="search"
          id="header-search"
          class="input"
          placeholder="Buscar personas…"
          autocomplete="off"
        />
      </form>

      <nav class="app-header__nav" aria-label="Navegación principal">
        <a href="/pages/notifications.html" class="btn--icon" aria-label="Notificaciones">
          ${BELL_ICON}
        </a>
        <a href="/pages/messages.html" class="btn--icon" aria-label="Mensajes">
          ${MAIL_ICON}
        </a>
        <div class="app-header__actions">
          <button type="button" class="theme-toggle" data-theme-toggle aria-label="Cambiar tema">
            ${SUN_ICON}
          </button>
          <a href="${options.activeUsername ? `/pages/profile.html?u=${options.activeUsername}` : '/pages/profile.html'}" aria-label="Mi perfil">
            <img
              src="${options.avatarUrl || '/assets/default-avatar.svg'}"
              alt=""
              class="avatar avatar--sm"
            />
          </a>
        </div>
      </nav>
    </div>
  `;
}
